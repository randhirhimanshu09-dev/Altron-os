# ALTRON OS Android Studio Project
Ready-to-compile native Android project for ALTRON OS.
Run ./gradlew assembleRelease to build signed APK.